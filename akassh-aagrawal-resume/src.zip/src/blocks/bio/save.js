import { useBlockProps, RichText } from '@wordpress/block-editor';
import * as WPIcons from '@wordpress/icons';
import { Icon } from '@wordpress/components';

export default function Save({ attributes }) {
	const { name, title, photo, socialLinks = [], contactItems = [] } = attributes;

	return (
		<div {...useBlockProps.save({ className: 'p-6 bg-white rounded-lg shadow-md' })}>
			{photo?.url && (
				<img src={photo.url} alt={photo.alt} className="w-24 h-24 rounded-full mb-4" />
			)}

			<RichText.Content tagName="h2" value={name} className="text-3xl font-bold" />
			<RichText.Content tagName="p" value={title} className="text-lg text-gray-600 mt-1" />

			<div className="flex flex-wrap gap-4 mt-4">
				{socialLinks.map((item, idx) => {
					const IconComponent = WPIcons[item.icon] || null;
					return (
						<a
							key={idx}
							href={item.url}
							className="flex items-center gap-2"
							title={item.title}
							target="_blank"
							rel="noopener noreferrer"
						>
							{IconComponent && (
								<Icon icon={IconComponent} style={{ color: item.iconColor || undefined }} />
							)}
							<span className="sr-only">{item.alt}</span>
						</a>
					);
				})}
			</div>

			<div className="mt-4">
				{contactItems.map((item, idx) => {
					const IconComponent = WPIcons[item.icon] || null;
					return (
						<div key={idx} className="flex items-center gap-2">
							{IconComponent && (
								<Icon icon={IconComponent} style={{ color: item.iconColor || undefined }} />
							)}
							<span>{item.text}</span>
						</div>
					);
				})}
			</div>
		</div>
	);
}
